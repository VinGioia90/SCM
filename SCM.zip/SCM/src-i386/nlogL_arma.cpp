// [[Rcpp::depends(RcppArmadillo)]]
#include <RcppArmadillo.h>
  
// [[Rcpp::export(name = "nll_logm_arma")]]
double nlogL_logm(arma::mat& eta, arma::mat& y) {
 uint32_t n = y.n_rows;
 uint32_t d = y.n_cols;
 uint32_t count = 0;

 uint32_t i;
 uint32_t j;
 uint32_t k;

 double nll = 0.0;
 
 arma::mat nAi(d,d,arma::fill::zeros);
 arma::rowvec ri(d,arma::fill::zeros); 

  for(i = 0; i < n; i++){ 

   for(j = 0; j < d; j++){
    ri(j) = y(i,j) - eta(i,j);
    nAi(j,j) = -eta(i,j + d);
   }

   count = 0;
   for(j=1; j<d; j++){
    for(k = 0; k < j; k++){
     nAi(j,k)= -eta(i,count+2*d);
     nAi(k,j) = -eta(i,count+2*d);
     count += 1;
    }
   } 
   nll += 0.5 * arma::as_scalar(ri * arma::expmat_sym(nAi) * ri.t()) - 0.5 * arma::trace(nAi);
 }
 
 return nll;
}
  
// [[Rcpp::depends(RcppArmadillo)]]

#include <RcppArmadillo.h>

 using namespace Rcpp;

// [[Rcpp::export(name = "nll_logm_arma")]]
arma::mat nlogL_logm() {
 
 
 arma::mat nAi(2,2,arma::fill::zeros);
 
 
 return nAi;
}
  